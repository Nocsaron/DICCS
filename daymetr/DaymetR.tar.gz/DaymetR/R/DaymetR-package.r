#' DaymetR.
#'
#' @name DaymetR
#' @docType package
NULL
